package com.embaudrit.employeesmanagers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeesmanagersApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeesmanagersApplication.class, args);
	}
}
