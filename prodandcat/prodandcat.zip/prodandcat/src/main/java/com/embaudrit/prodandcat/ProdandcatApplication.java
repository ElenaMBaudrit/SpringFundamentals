package com.embaudrit.prodandcat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdandcatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdandcatApplication.class, args);
	}
}
