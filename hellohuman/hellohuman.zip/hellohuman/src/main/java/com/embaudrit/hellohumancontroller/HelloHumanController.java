package com.embaudrit.hellohumancontroller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloHumanController {

//    @RequestMapping("/")
//    public String index(@RequestParam(value="name", defaultValue = "Human") String query, Model model) {
//        model.addAttribute("name", query);
//        return "index.jsp";
//    }
//    
}
